import React, { useState } from "react";
import axios from "axios";

const CreateOrder = () => {
  const [meals, setMeals] = useState([]);
  const [date, setDate] = useState("");
  const [quantities, setQuantities] = useState({
    breakfast: 0,
    lunch: 0,
    dinner: 0,
  });

  const handleMealChange = (e) => {
    const { value, checked } = e.target;
    if (checked) {
      setMeals((prev) => [...prev, value]);
    } else {
      setMeals((prev) => prev.filter((meal) => meal !== value));
    }
  };

  const handleQuantityChange = (e) => {
    const { name, value } = e.target;
    setQuantities((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const orderData = {
      meals: meals.map((meal) => ({
        mealType: meal,
        quantity: quantities[meal],
      })),
      date,
    };

    try {
      const token = localStorage.getItem("token"); // Assuming the token is stored in local storage
      const response = await axios.post(
        "http://localhost:5000/api/orders", // Replace with your API endpoint
        orderData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      console.log("Order created:", response.data);
      // Optionally reset the form
      setMeals([]);
      setQuantities({ breakfast: 0, lunch: 0, dinner: 0 });
      setDate("");
    } catch (error) {
      console.error("Error creating order:", error);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Create Order</h2>
      <div>
        <label>
          <input
            type="checkbox"
            value="breakfast"
            checked={meals.includes("breakfast")}
            onChange={handleMealChange}
          />
          Breakfast
        </label>
        {meals.includes("breakfast") && (
          <input
            type="number"
            name="breakfast"
            value={quantities.breakfast}
            min="1"
            onChange={handleQuantityChange}
            placeholder="Quantity"
            required
          />
        )}
      </div>
      <div>
        <label>
          <input
            type="checkbox"
            value="lunch"
            checked={meals.includes("lunch")}
            onChange={handleMealChange}
          />
          Lunch
        </label>
        {meals.includes("lunch") && (
          <input
            type="number"
            name="lunch"
            value={quantities.lunch}
            min="1"
            onChange={handleQuantityChange}
            placeholder="Quantity"
            required
          />
        )}
      </div>
      <div>
        <label>
          <input
            type="checkbox"
            value="dinner"
            checked={meals.includes("dinner")}
            onChange={handleMealChange}
          />
          Dinner
        </label>
        {meals.includes("dinner") && (
          <input
            type="number"
            name="dinner"
            value={quantities.dinner}
            min="1"
            onChange={handleQuantityChange}
            placeholder="Quantity"
            required
          />
        )}
      </div>
      <div>
        <label>
          Date:
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            required
          />
        </label>
      </div>
      <button type="submit">Submit Order</button>
    </form>
  );
};

export default CreateOrder;
