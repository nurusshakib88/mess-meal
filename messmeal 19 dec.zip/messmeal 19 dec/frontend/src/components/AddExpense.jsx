import React, { useState, useEffect } from "react";
import axios from "axios";

const AddExpense = () => {
  const [type, setType] = useState("");
  const [amount, setAmount] = useState("");
  const [month, setMonth] = useState("");
  const [totalExpenses, setTotalExpenses] = useState([]);
  const [monthlyMeals, setMonthlyMeals] = useState([]);
  const [perMealCost, setPerMealCost] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    fetchTotalExpenses();
    fetchMonthlyMeals(); // Fetch the monthly meals data when the component mounts
  }, []);

  // Fetch total expenses
  const fetchTotalExpenses = async () => {
    try {
      const token = localStorage.getItem("token");
      const response = await axios.get(
        "http://localhost:5000/api/expenses/get-expenses",
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      setTotalExpenses(response.data);
    } catch (err) {
      setError(err.response?.data?.message || "An error occurred.");
    }
  };

  // Fetch monthly meals data
  const fetchMonthlyMeals = async () => {
    try {
      const token = localStorage.getItem("token");
      const response = await axios.get(
        "http://localhost:5000/api/orders/summary/monthly-meals",
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      setMonthlyMeals(response.data);
    } catch (err) {
      setError(err.response?.data?.message || "An error occurred.");
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!type || !amount || !month) {
      setError("All fields are required");
      return;
    }

    try {
      const token = localStorage.getItem("token");
      await axios.post(
        "http://localhost:5000/api/expenses/add-expense",
        { type, amount: parseFloat(amount), month },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      fetchTotalExpenses();
      alert("Expense added successfully!");
    } catch (err) {
      setError(err.response?.data?.message || "Failed to add expense.");
    }
  };

  // Calculate per meal cost for a selected month
  const calculateCost = (selectedMonth) => {
    // Find the monthly meal count for the selected month
    const mealData = monthlyMeals.find(
      (meal) =>
        `${meal._id.year}-${String(meal._id.month).padStart(2, "0")}` ===
        selectedMonth
    );

    if (!mealData) {
      setError("No meal data found for this month.");
      return;
    }

    const totalMeals = mealData.totalMeals;

    // Find the total expenses for the selected month
    const expenseData = totalExpenses.find(
      (expense) => expense.month === selectedMonth
    );

    if (!expenseData) {
      setError("No expenses found for this month.");
      return;
    }

    const totalExpensesForMonth = expenseData.totalExpense;

    // Calculate the per meal cost
    const perMealCost = totalMeals > 0 ? totalExpensesForMonth / totalMeals : 0;
    setPerMealCost(perMealCost);
  };

  return (
    <div>
      <h2>Add Expense</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Expense Type:</label>
          <select
            value={type}
            onChange={(e) => setType(e.target.value)}
            required
          >
            <option value="">Select Type</option>
            <option value="utility">Utility</option>
            <option value="food">Food</option>
            <option value="other">Other</option>
          </select>
        </div>
        <div>
          <label>Amount:</label>
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Month (YYYY-MM):</label>
          <input
            type="month"
            value={month}
            onChange={(e) => setMonth(e.target.value)}
            required
          />
        </div>
        <button type="submit">Add Expense</button>
      </form>

      <h3>Total Expenses for Each Month</h3>
      {totalExpenses.length > 0 ? (
        <ul>
          {totalExpenses.map((expense) => (
            <li key={expense.month}>
              {expense.month}: ${expense.totalExpense.toFixed(2)}{" "}
              <button onClick={() => calculateCost(expense.month)}>
                Calculate Per Meal Cost
              </button>
            </li>
          ))}
        </ul>
      ) : (
        <p>No expenses found.</p>
      )}

      {perMealCost !== null && (
        <div>
          <h3>Per Meal Cost</h3>
          <p>${perMealCost.toFixed(2)}</p>
        </div>
      )}

      {error && <div style={{ color: "red" }}>{error}</div>}
    </div>
  );
};

export default AddExpense;
