// src/pages/Home.jsx
import { useContext, useEffect, useState } from "react";
import { AuthContext } from "../contexts/AuthContext";
import CreateUser from "../components/CreateUser";
import Members from "./Members";
import CreateUserByAdmin from "../components/CreateUserByAdmin";
import CreateOrder from "../components/CreateOrder";
import AllOrders from "../components/AllOrders";
import DepositRequest from "../components/DepositRequest";
import AddExpense from "../components/AddExpense";

const Home = () => {
  const { auth, logout } = useContext(AuthContext);
  const [isManager, setIsManager] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  // Check if auth exists before rendering the component
  useEffect(() => {
    if (auth && auth.user) {
      // Check if the user is manager or admin
      if (auth.user.role === "manager") {
        setIsManager(true);
      } else if (auth.user.role === "admin") {
        setIsAdmin(true);
      } else {
        setIsManager(false);
        setIsAdmin(false);
      }
    }
  }, [auth]);

  // Show loading message if auth is not yet available
  if (!auth || !auth.user) {
    return <p>Loading...</p>; // You can also redirect to the login page if needed
  }

  return (
    <div>
      <h1>Welcome to the Dashboard, {auth.user.name}</h1>

      {/* Show CreateUser component only if the user is a manager or admin */}
      {isManager && <CreateUser />}

      {isManager && <AddExpense />}

      {isAdmin && <CreateUserByAdmin />}

      {(isManager || isAdmin) && <Members />}

      {/* {isManager && <MealPlan />} */}

      {!isAdmin && (
        <>
          <CreateOrder />
          <AllOrders />

          <DepositRequest />
        </>
      )}

      {!isAdmin && <>hello</>}

      {/* Logout button */}
      {auth && (
        <button onClick={logout} className="mt-10">
          Logout
        </button>
      )}
    </div>
  );
};

export default Home;
